#include <iostream>
#include <sstream>
#include "position.h"

using namespace std;

int main()
{
   Position source;
   Position dest;

   cout << source << dest;
   
   return 0;
}
