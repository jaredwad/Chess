/***********************************************************************
* Program:
*    Project 3, Chess with Objects
*    Brother Helfrich, CS165
* Author:
*    The Key
* Summary: 
*    This fill will keep track of the move on the board
************************************************************************/

#include <iostream>
#include "board.h"
#include "move.h"
using namespace std;

/*************************************
 * main
 **************************************/
int main()
{
   Board board;
   cout << board;
   return 0;
}
